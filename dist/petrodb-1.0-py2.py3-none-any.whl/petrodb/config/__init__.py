def readConfig():
    return None